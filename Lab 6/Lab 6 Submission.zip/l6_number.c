#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(void){
	int n, output;
	time_t tm;
	
	srand((unsigned)time(&tm));			//make different random number;
	printf("Enter a number beween 2 and 9 : ");
	
	scanf("%d", &n);
	
	output = n;
	
	for(int controller=0; controller < n ; controller++){
		
		int randomnumber = (rand() % 7) + 2 ;		//get randomnumber
		
		printf("%d:", randomnumber);
		
		if (randomnumber < 5){					// if the number is close to 0 than 10
			
			for(int left=0; left < (randomnumber - 1); left++){
				
				printf("%d", output);
				
			}
				
		}else{									// if the number is close to 10 than 0
			
			for(int space = 0; space < randomnumber ; space ++){	// Output the spaces before number
				
				printf(" ");
				
			}
			
			for(int printnum = 0; printnum < (10 - randomnumber); printnum++){	//Output the number
				
				printf("%d", output);
				
			}
		}
		printf("\n");	// Start a new line
		output--;		//the output number-1 and go to another loop
	}
}
