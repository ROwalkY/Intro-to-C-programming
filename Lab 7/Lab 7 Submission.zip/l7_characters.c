#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(void){
	int n;
	char output;
	time_t tm;
	
	srand((unsigned)time(&tm));			//make different random number;
	printf("Enter a number beween 2 and 35 : ");
	
	scanf("%d", &n);
	if(n>9){
			output = 122 - (35-n);		//transfer numbers into characters
		}else{
			output = n + 48;
		}
	
	for(int controller=0; controller < n ; controller++){
		
		int randomnumber = (rand() % 8) + 2 ;		//get randomnumber
		
		
	
		printf("%d:", randomnumber);
		
		if (randomnumber < 5){					// if the number is close to 0 than 10
			
			for(int left=0; left < (randomnumber - 1); left++){
				
				printf("%c", output);
				
			}
				
		}else{									// if the number is close to 10 than 0
			
			for(int space = 0; space < randomnumber ; space ++){	// Output the spaces before number
				
				printf(" ");
				
			}
			
			for(int printnum = 0; printnum < (10 - randomnumber); printnum++){	//Output the number
				
				printf("%c", output);
				
			}
		}
		printf("\n");	// Start a new line
		output--;		//the output number-1 and go to another loop
		
		if(output==96){
			output = 57;
		}
	}
	return 0;
}
