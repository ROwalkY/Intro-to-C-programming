#include <stdio.h>

	int main(void){
		int factorial, value = 0;
		int number;
		short s;
		unsigned short us;
		unsigned int ui;
		long l;
		unsigned long ul;
		long long int ll;
		unsigned long long int ull;
		long double ld;
		
		do{
			
			printf("Enter a positive integer (or -ve integer to exit) : ");
			
			scanf("%d", &number);
			
			//short fails at 8
			//unsigned short fails at 9
			//int and unsigned int fails at 13
			//long , unsigned long , long long ,and unsigned long long fails at 21
			//long double fails at 1781
			
			// By using "long double" type, the exact factorial number can be found
			// the number is 5.10909e+19  
			
			
			
			
			
			if(number >= 0)
			{
				
				if (value == 0){
					s =1;
					us = 1;
					ui = 1;
					l = 1;
					ul = 1;
					ll = 1;	
					ld = 1.0f;
					factorial = 1;
					ull = 1;
				
				}else{
					s =0;
					us = 0;
					ui = 0;
					l = 0;
					ul = 0;
					ll = 0;	
					ld = 0.0f;
					ull = 0;
					factorial = 0;
				}
				
				for(value = number; value >0 ; value--){
				
					ull  *=  value ;
					s	*= value;
					us	*= value;
					ui	*= value;
					l	*= value;
					ul	*= value;
					ll	*= value;
					ld *= value;
					factorial *= value;
					
				}
			
				
				
				
				printf(" %hd (short, size = %lu)\n", s , sizeof(s) );
				
				
				printf(" %hu (unsigned short, size = %lu)\n", us , sizeof(us) );
				
				
				printf(" %d (int, size = %lu)\n", factorial , sizeof(factorial) );
				
				
				printf(" %u (unsigned int, size = %lu)\n", ui , sizeof(ui) );
				
				
				printf(" %ld (long, size = %lu)\n", l , sizeof(l) );
				
				
				printf(" %lu (unsigned long, size = %lu)\n", ul , sizeof(ul) );
				
				
				printf(" %lld (long long, size = %lu)\n", ll , sizeof(ll) );
				
				
				printf(" %llu (unsigned long long, size = %lu)\n", ull , sizeof(ull) );
				
				
				printf(" %Lg (long double, size = %lu)\n", ld , sizeof(ld) );
			}
			

			
		}while( number >= 0 );
		
		printf("Thank you for using my software :)-");
		
		return 0;
	}
