#include <stdio.h>
#include <tgmath.h>
#define M_PI 3.14159265358979323846  /*Define the value of Pi*/
	int main(void){
		float radius,height,volume;
		printf("Please enter the radius and height of the cylinder(radius,height): ");
		scanf("%f,%f",&radius,&height);
		printf("Enter Radius: %.1f\n",radius);
		if(radius>=2){                      /*Check the value of radius*/
			if(height>radius){				/*If height is bigger than radius then continue*/
				printf("Enter Height: %.1f\n",height);
				volume=M_PI*pow(radius,2.0)*height;        /*Calculate the volume*/
				printf("The volume is: %.2f",volume);
			}else{							/*If value of height is less than radius*/
				printf("Enter Height: %.1f\n",height);
				printf("Height has to be bigger than radius.\n");
			}
		}else{								/*If value of radius is less than 2*/
			printf("Radius cannot be smaller than 2.\n");
		}
		return 0;
	}