#include <stdio.h>
#include <tgmath.h>
#define M_PI 3.14159265358979323846
	int main(void){
		float radius = 5.0f, height, volume;
		do
		{
			printf("Enter the height (0 to exit program): ");
			scanf("%f",&height);
			
			if(height > radius){
				
				volume = M_PI*pow(radius,2.0)*height;
				
				printf("The volume is: %.2f\n",volume);
				
			}else if (height != 0){
				
				printf("Height has to be bigger than radius (5.0).\n");
				
			}	
		}while (height != 0 );
		
		printf("Thank you for using my software.");
		
		return 0;
	}
	
