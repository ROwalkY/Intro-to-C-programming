#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
int main(void)
{
	int width, height;
	int heightlength = 0, num = 0;
	char character = '1';
	srand((unsigned) time(NULL));
	
	do{
	
	
	printf("Range: 9 < w < 21, 2 < h < 62\n");
	
	printf("Enter width and height : ");
	
	scanf("%d%d", &width, &height);
	
	
	}while( ( (width < 10) && (width > 20) ) && ( ( height < 3) && (height > 61) ) );
	
	int array[height] ;
	
	for( num = 0 ; num < height ; num++ ){
	
		
		//print spaces
		
		int randomnumber = rand() % (width - 2) + 2 ; 
		
		printf("%02d: ", randomnumber);
		
		array [heightlength] = randomnumber;
		
		if(array[heightlength] > floor(width/2) ){
			
			for(int space = 0; space < randomnumber; space++ ){
				
				printf(" ");
				
			}
			
			for(int charnum_1 = 0; charnum_1 < width - array[heightlength] ; charnum_1++){
				
				printf("%c", character);
				
			}
		}else{
			
			for (int charnum_2 = 0; charnum_2 < (array[heightlength] - 1) ; charnum_2++ ){
				
				printf("%c", character);
				
			}
			
		}
		
		heightlength++;
		character++;
		
		switch(character){
			case 58:
				character = 97;
				break;
			case 123:
				character = 65;
				break;
		}
		
		printf("\n");
		
		
		
		
	}
	int count = 0;
	for(int statistic = 0; statistic < height; statistic++){
			
			if(array[statistic]== floor(width/2) ){
				count++;
			}
			
		}
		
		int floornum = floor(width/2);
		
		float percentage = (float)count / height * 100.0f ;
		
		
		printf("Amoung %d numbers, the percentage of %d is %.2f%%", height, floornum , percentage);
	return 0;
}
