#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void
flip(void){
	srand((unsigned)time(NULL));
	int heads= 0, tails=0;
	for(int i =0; i < 100; ++i){
	
		int randomnumber = rand() % 2;
		if(randomnumber == 1){
			printf("Heads ");
			heads++;
		}else{
			printf("Tails ");
			tails++;
		}
	}
	printf("\n\nThe total number of Heads was %hd\n", heads);
	printf("The total number of Tails was %hd\n", tails);
}

int main(void){
	flip();
	return 0;
}
