#include <stdio.h>

#include <math.h>

#define Customernum 3

double	
calculateCharges(double x){
	double charge;
	if(x<= 3.0){
		charge = 2.00;
	}else{
		
		charge = 2.00 + 0.5*(ceil(x)-3);
		charge = charge > 10.00? 10.00 : charge;
		
	}
	return charge;
}

int main(void){
	
	double hoursum,chargesum;
	
	double hourarray[Customernum];
	
	
	for(unsigned int i = 0; i < Customernum ; ++i){
		scanf("%lf",&hourarray[i]);
	}
	
	printf("%15s%15s%15s\n","Cars","Hours","Charge");
	
	double Currentcharge;
	
	for(unsigned int i = 0; i < Customernum ; ++i ){
		
		hoursum += hourarray[i];
		
		Currentcharge = calculateCharges(hourarray[i]);
		
		chargesum += Currentcharge;
		
		printf("%15d%15.1f%15.2f\n", i, hourarray[i], Currentcharge);
		
	}
	
	printf("%15s%15.1f%15.2f\n","TOTAL",hoursum,chargesum);
	return 0;
}
